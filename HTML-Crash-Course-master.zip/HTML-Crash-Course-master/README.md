# HTML Crash Course

Tutorial List:
<ol>
  <li>Setup and Overview</li>
  
  <li>Basic Tags</li>
  
  <li>Headings</li>
  
  <li>Lists</li>
  
  <li>Links</li>
  
  <li>Images</li>
  
  <li>Tables</li>
  
  <li>Advanced Tables</li>
  
  <li>Meta Tags</li>
  
  <li>Description List</li>
  
  <li>Presentation</li>
  
  <li>iframe</li>
  
  <li>Videos</li>
  
  <li>Audio</li>
  
  <li>Forms</li>
  
  <li>CSS</li>
  
  <li>JavaScript</li>
</ol>
